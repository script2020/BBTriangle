package triangle;

public class TriangleTest {
    public static void testIfTriangleIsEquilateral() {
        Triangle triangle = new Triangle(3, 3, 3);
        assert(triangle.classify().equals("equilateral"));
    }

    public static void testIfTriangleIsIsosceles() {
        Triangle triangle = new Triangle(3, 3, 4);
        assert(triangle.classify().equals("isossceles"));
    }

    public static void testIfTriangleIsScalene() {
        Triangle triangle = new Triangle(3, 4, 5);
        assert(triangle.classify().equals("scalene"));
    }

    public static void testIfTriangleIsRightAngled() {
        Triangle triangle = new Triangle(3, 4, 5);
        assert(triangle.classify().equals("right-angled"));
    }

    public static void testIfTriangleIsImpossible() {
        Triangle triangle = new Triangle(1, 2, 3);
        assert(triangle.classify().equals("impossible"));
    }
}
